package msgServer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

public class AddingReminder 
{	
	private BufferedWriter out;
	private BufferedReader in;
	private MsgSvrConnection conn;
	private Properties userInfo;

	public void execute() throws IOException 
	{
		//This class was not moved forward due to difficulties, as such, this class was abandoned
		//and a different approach to reminders went forward
		String time = in.readLine();
		String content = in.readLine();
		String user = conn.getCurrentUser();
		
		try
		{
			String dbURL = "jdbc:odbc:reminders";
			String driverName = "sun.jdbc.odbc.JdbcOdbcDriver";
			
			//connects
			Connection conn = DriverManager.getConnection(dbURL);
			
			Statement st = conn.createStatement();
			
			//Sets this string as the sql statement that will be executed
			String sql = "INSERT INTO Reminder_Table VALUES('1', '" + time + "', '" + user + "', '" + content + "')";
			
			//executes the sql line
			ResultSet rs = st.executeQuery(sql);
			
			while (rs.next())
			{
				System.out.println("\n" + rs.getString(2));
			}
		}
		
		catch (Exception exc)
		{
			exc.printStackTrace();
		}
	}

	public AddingReminder(BufferedReader in, BufferedWriter out, 
			MsgSvrConnection serverConn)
	{
		this.out = out;
		this.in = in;
		this.conn = serverConn;
	}
}
