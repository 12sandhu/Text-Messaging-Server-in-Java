package msgServer;

import java.util.Properties;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class RegisterAccountCommand implements Command
{
	private BufferedWriter out;
	private BufferedReader in;
	private MsgSvrConnection conn;
	private Properties userInfo;

	public void execute() throws IOException 
	{
		//First it will get the username you want to choose
		String username = in.readLine();
		//Then you will choose the password
		String password = in.readLine();
		
		FileWriter file = new FileWriter("src/pwd.txt", true);
		BufferedWriter out2 = new BufferedWriter(file);
		
		//Print out the username and password to check
		conn.userMsg("Adding user: " + username + "(" + password +")");
		//Write to the pwd.txt file to ensure the account remains after server shutdown
		out2.newLine();
		out2.write(username + "=" + password);
		out2.close();
		
		//It is successful,
		out.write("200\r\n");  
		out.flush();
		
		//calls this method to add the details to the actual property object
		conn.getServer().addUserAccount(username, password);
	}
	
	public RegisterAccountCommand(BufferedReader in, BufferedWriter out, 
			MsgSvrConnection serverConn)
	{
		this.out = out;
		this.in = in;
		this.conn = serverConn;
	}
}
