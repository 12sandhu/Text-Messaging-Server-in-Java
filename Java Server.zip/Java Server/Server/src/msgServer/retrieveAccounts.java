package msgServer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class retrieveAccounts implements Command
{
	private BufferedWriter out;
	private BufferedReader in;
	private MsgSvrConnection conn;
	
	public void execute() throws IOException 
	{
		String line = null; //The line will store the current line from the reader
		String[] delim = null; //This stores every word from the line
		
		FileReader file = new FileReader("src/pwd.txt");
		in = new BufferedReader(file);

		//reads until the end
		while ((line = in.readLine()) != null)
		{
			//It will get every account by reading the first word of every line (The keys) and storing them
			delim = line.split("=");
			System.out.println(delim[0]);
			out.write(delim[0] + "\r\n"); //Every name is written out
		}
		
		out.flush();
		out.close();
		//Closes the stream and connection
	}
	
	public retrieveAccounts(BufferedReader in, BufferedWriter out, MsgSvrConnection serverConn)
	{
		this.out = out;
		this.in = in;
		this.conn = serverConn;
	}
}
