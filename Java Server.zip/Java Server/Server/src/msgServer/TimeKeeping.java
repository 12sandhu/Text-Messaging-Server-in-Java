package msgServer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalTime;

public class TimeKeeping extends Thread
{
	private BufferedWriter out;
	private BufferedReader in;
	private MessageServer conn;

	public TimeKeeping(MessageServer conn)
	{
		this.conn = conn;
	}

	public void run()
	{
		LocalTime time = LocalTime.now(); //get the current time
		String[] lineContent = null; //will later store every word in a line
		String timeshort = null; //will later store a trimmed version of time
		String line = null; //will later contain a line

		File input = new File("src/reminders.txt");
		File tempinput = new File("src/remindersTemp.txt");

		try 
		{
			while(true) //looping until the server shuts down, checking for reminders
			{
				try
				{		
					FileWriter writer = new FileWriter(tempinput, true);
					FileReader read = new FileReader(input);
					in = new BufferedReader(read);
					BufferedWriter print = new BufferedWriter(writer);

					time = LocalTime.now(); //gets the current time
					timeshort = ((time.toString()).substring(0, Math.min((time.toString()).length(), 5))); //trims the time so it only retrieves the first 5 characters. This gets a 24 hour format just including hours and minutes

					while((line = in.readLine()) != null) //Read until the end of the file
					{

						if (line.contains(timeshort)) //If the file contains the time then retrieve the line
						{
							System.out.println("We reached this point!");
							lineContent = line.split("�=");
							Message m = new Message(lineContent[1], "Reminder", lineContent[2]); //Each word is taken and then aids in the construction of a message
							conn.getMessages().addMessage(m); //Adds the new message
						}
					}
					Thread.sleep(60000); //Checks every minute
				} 

				catch (InterruptedException e) 
				{
					System.out.println(e);
				}
			}
		} 
		catch (IOException e2) 
		{
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}	
	}
}
