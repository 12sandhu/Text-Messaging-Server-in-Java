package msgServer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

public class UpdateAccountCommand implements Command
{
	private BufferedWriter out;
	private BufferedReader in;
	private MsgSvrConnection conn;
	private Properties userInfo;

	@Override
	public void execute() throws IOException 
	{
		//Enter the password you want to change.
		String password = in.readLine();
		//String email = in.readLine();
		//String phone = in.readLine();
		
		
		//User must re-enter password for validation.
		if ((conn.getServer().getUserPassword(conn.getCurrentUser().toString())).equals(password))
		{
			//User will enter new details
			password = in.readLine();
			//email = in.readLine();
			//phone = in.readLine();

			//Print out the username and password to check
			conn.userMsg("Changing user: " + conn.getCurrentUser().toString() + "'s password to (" + password +")");
			//It is successful,
			out.write("200\r\n");  
			out.flush();

			//Call the method in the main server class and update the property object
			conn.getServer().changeUserAccount(conn.getCurrentUser().toString(), password);
			
		}
		else //If no one is logged in the following will be executed
		{
			new ErrorCommand(in, out, conn, "You entered the wrong details").execute(); //An error message will be displayed
		}
		
	}

	public UpdateAccountCommand(BufferedReader in, BufferedWriter out, 
			MsgSvrConnection serverConn)
	{
		this.out = out;
		this.in = in;
		this.conn = serverConn;
	}
}
