package msgServer;
import java.io.BufferedReader;
import java.io.BufferedWriter; 
import java.io.IOException;

public class GetAllMsgsCommand implements Command 
{
	private BufferedReader in;
	private BufferedWriter out;
	private MsgSvrConnection conn;

	public GetAllMsgsCommand(BufferedReader in, BufferedWriter out, MsgSvrConnection serverConn){ 
		this.in = in;
		this.out = out;
		this.conn = serverConn;
	}

	public void execute() throws IOException{
		//declare a variable user of type String and use it to get the user from the inputstream
		String user = in.readLine();
		System.out.println(user);
		int i = 0;
		//check if current user is not equal to null and current user is equal to the user (use the method getCurrentUser())
		if (conn.getCurrentUser() != null && conn.getCurrentUser().equals(user)) {
			//intialise an array (msgs) that is used to hold all the messages read and set it's initialised value to null 
			Message[] m = null;
			//use the method getAllMessages(user) to populate the msgs array
			//check if msgs is not equal to null 
			if ((m = conn.getServer().getMessages().getAllMessages(user)) != null) {
				//write to the OutputStream the message status code as specified in the protocol   
				out.write("" + MsgProtocol.GET_ALL_MESSAGES + "\r\n");
				
				while (i < m.length) {
					//Loop through the messages and write the sender, date and content to the outputstream (use provided methods) 
					out.write(i + "\r\n");
					out.write(m[i].getSender() + "\r\n");
					out.write(m[i].getDate() + "\r\n");
					out.write(m[i].getContent() + "\r\n");
					i++;
				}
				//write the length of the messages returned
				out.write("\r\n Number of messages: " + i);
				//Flush the outputstream
				out.flush();
			}
			else {
				//capture adequet errors (No messages) or (You are not logged on)
				(new ErrorCommand(in, out,conn, "No messages")).execute();    
			}
		} 
		else {
			//capture adequet errors (No messages) or (You are not logged on)
			(new ErrorCommand(in, out,conn, "You are not logged on")).execute();
		}
	}
}
