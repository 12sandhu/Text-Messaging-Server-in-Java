package msgServer; //Connects to package

import java.io.BufferedReader; //Imports a buffered reader to read a file
import java.io.BufferedWriter; //Imports a buffered writer to write to a file
import java.io.FileWriter; //Imports a file writer to open a file in write mode
import java.io.IOException; //Imports IOException to throw an exception if one occurs

public class SetReminderCommand implements Command
{
	private BufferedWriter out; //Initializes a buffered writer called out
	private BufferedReader in; //Initializes a buffered reader called in
	private MsgSvrConnection conn; //Initializes a connection to a server, from MsgSvrConnection class, called conn
	@Override
	public void execute() throws IOException
	{
		//This is declared as 'x' to avoid an error when determining the length later in the code
		String time = "x";

		if (conn.getCurrentUser() != null) //If statement checks if a user is logged in
		{
			time = in.readLine(); //Initializes a string called time
			String reminder = in.readLine(); //Initializes a string called reminder
			String username = conn.getCurrentUser(); //Initializes a string called username

			FileWriter file = new FileWriter("src/reminders.txt", true); //Creates a file writer and passes it the location of a file containing the reminders
			BufferedWriter out = new BufferedWriter(file); //Creates a buffered writer with a file selected

			out.write(time + "�=" + username + "�=" + reminder); //Writes time, username and reminder to a file with �= as delimiters
			out.newLine(); //Writes new line to a file
			out.close(); //Closes the buffered writer
		}
		else //If no one is logged in the following will be executed
		{
			new ErrorCommand(in, out, conn, "No one is logged in...").execute(); //An error message will be displayed
		}
	}

	public SetReminderCommand(BufferedReader in, BufferedWriter out, MsgSvrConnection serverConn)
	{
		this.out = out; //The initialized buffered writer becomes the buffered writer the server uses
		this.in = in;  //The initialized buffered reader becomes the buffered reader the server uses
		this.conn = serverConn;  //The initialized connection becomes the connection the server uses
	}
}