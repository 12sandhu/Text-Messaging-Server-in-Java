package msgClient;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.Scrollbar;
import java.awt.Font;
import javax.swing.JComboBox;
import java.awt.Panel;
import javax.swing.DefaultComboBoxModel;

public class MessageClient {

	private JFrame frame;
	private JTextField txtIP;
	private JTextField txtPort;
	private JTextField txtUsername;
	private JTextField txtPassword;
	private boolean LoggedCheck = false;
	private JTextField txtSendChat;
	private JTextField txtCurrentPass;
	private JTextField txtNewPass;
	private JTextField txtReminder;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MessageClient window = new MessageClient();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MessageClient() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		ConnectionClass conn = new ConnectionClass();
		ConnectionClass conn2 = new ConnectionClass();
		
		PrintWriter out = null;
		BufferedReader in = null;
		
		
		
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 165, 0));
		frame.setResizable(false);
		frame.setBounds(100, 100, 615, 430);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		txtIP = new JTextField();
		txtIP.setBackground(Color.LIGHT_GRAY);
		txtIP.setText("localhost");
		txtIP.setBounds(50, 12, 86, 20);
		frame.getContentPane().add(txtIP);
		txtIP.setColumns(10);
		
		txtPort = new JTextField();
		txtPort.setBackground(Color.LIGHT_GRAY);
		txtPort.setText("1255");
		txtPort.setBounds(50, 43, 86, 20);
		frame.getContentPane().add(txtPort);
		txtPort.setColumns(10);
		
		JLabel lblIp = new JLabel("IP:");
		lblIp.setBounds(22, 15, 19, 14);
		frame.getContentPane().add(lblIp);
		
		JLabel lblPort = new JLabel("Port:");
		lblPort.setBounds(22, 46, 34, 14);
		frame.getContentPane().add(lblPort);
		
		JLabel lblConError = new JLabel("");
		lblConError.setForeground(Color.RED);
		lblConError.setBounds(153, 45, 139, 14);
		frame.getContentPane().add(lblConError);
		
		txtUsername = new JTextField();
		txtUsername.setBackground(Color.LIGHT_GRAY);
		txtUsername.setEnabled(false);
		txtUsername.setBounds(498, 13, 86, 20);
		frame.getContentPane().add(txtUsername);
		txtUsername.setColumns(10);
		
		txtPassword = new JTextField();
		txtPassword.setBackground(Color.LIGHT_GRAY);
		txtPassword.setEnabled(false);
		txtPassword.setBounds(498, 41, 86, 20);
		frame.getContentPane().add(txtPassword);
		txtPassword.setColumns(10);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setBounds(436, 16, 64, 14);
		frame.getContentPane().add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(436, 47, 76, 14);
		frame.getContentPane().add(lblPassword);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 140, 0));
		panel.setBounds(22, 82, 502, 10);
		frame.getContentPane().add(panel);
		
		JLabel lblUser = new JLabel("Please Login");
		lblUser.setBounds(22, 103, 245, 14);
		frame.getContentPane().add(lblUser);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setForeground(new Color(0, 255, 0));
		btnLogin.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnLogin.setBackground(Color.DARK_GRAY);
		btnLogin.setBounds(337, 12, 89, 23);
		frame.getContentPane().add(btnLogin);
		
		JButton btnConnect = new JButton("Connect");
		btnConnect.setForeground(new Color(0, 255, 0));
		btnConnect.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnConnect.setBackground(Color.DARK_GRAY);
		btnConnect.setBounds(143, 11, 124, 23);
		frame.getContentPane().add(btnConnect);
		
		JPanel pnlChat = new JPanel();
		pnlChat.setBounds(10, 128, 300, 234);
		frame.getContentPane().add(pnlChat);
		
		JTextArea txtarChatRoom = new JTextArea(12, 24);
		txtarChatRoom.setEditable(false);
		JScrollPane scroll = new JScrollPane(txtarChatRoom);
		scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		
		pnlChat.add(scroll);
		
		txtSendChat = new JTextField();
		txtSendChat.setBackground(Color.LIGHT_GRAY);
		txtSendChat.setBounds(10, 370, 300, 20);
		frame.getContentPane().add(txtSendChat);
		txtSendChat.setColumns(10);
		
		
		
		JTextArea txtarUsers = new JTextArea();
		txtarUsers.setBackground(Color.LIGHT_GRAY);
		txtarUsers.setBounds(473, 178, 111, 156);
		frame.getContentPane().add(txtarUsers);
		
		Scrollbar scrollbar = new Scrollbar();
		scrollbar.setBounds(486, 178, 17, 156);
		frame.getContentPane().add(scrollbar);
		
		JLabel lblRegisteredUsers = new JLabel("Registered Users");
		lblRegisteredUsers.setBounds(473, 156, 111, 14);
		frame.getContentPane().add(lblRegisteredUsers);
		
		JComboBox cbxUsers = new JComboBox();
		cbxUsers.setBounds(485, 370, 99, 20);
		frame.getContentPane().add(cbxUsers);
		
		JLabel lblChooseRecipient = new JLabel("Choose Recipient");
		lblChooseRecipient.setForeground(new Color(0, 128, 0));
		lblChooseRecipient.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblChooseRecipient.setBounds(483, 345, 116, 14);
		frame.getContentPane().add(lblChooseRecipient);
		
		JButton btnSendMsg = new JButton("Send");
		btnSendMsg.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				
				String user = txtUsername.getText();
				String recip = cbxUsers.getSelectedItem().toString();
				String msg = null;
				
				if (txtSendChat.getText() != null)
				{
					msg = txtSendChat.getText();
					conn.sendMessage(user, recip, msg);
					
					txtarChatRoom.append(user + "(to " + recip + "): " + msg + "\r\n");
				}
				
				else
				{
					
				}
				
			}
		});
		
		
		btnSendMsg.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnSendMsg.setForeground(new Color(0, 255, 0));
		btnSendMsg.setBackground(Color.DARK_GRAY);
		btnSendMsg.setBounds(318, 369, 76, 23);
		frame.getContentPane().add(btnSendMsg);
		
		JButton btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				String user = txtUsername.getText();
				String pass = txtPassword.getText();
				
				conn.registerAcc(user, pass);
				
				JOptionPane.showMessageDialog(null, "Account Created");
			}
		});
		btnRegister.setBounds(337, 40, 89, 23);
		frame.getContentPane().add(btnRegister);
		
		JButton btnChangePass = new JButton("Change Password");
		btnChangePass.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{
				String oldpass = txtCurrentPass.getText();
				String newpass = txtNewPass.getText();
				
				conn.changeAccount(oldpass, newpass);
				
				if (conn.getResponse().equals("200"))
				{
					JOptionPane.showMessageDialog(null, "Password Updated");
				}
			}
		});
		
		btnChangePass.setBounds(318, 103, 139, 23);
		frame.getContentPane().add(btnChangePass);
		
		txtCurrentPass = new JTextField();
		txtCurrentPass.setBounds(337, 156, 86, 20);
		frame.getContentPane().add(txtCurrentPass);
		txtCurrentPass.setColumns(10);
		
		JLabel lblCurrentPassword = new JLabel("Current Password");
		lblCurrentPassword.setBounds(337, 138, 120, 14);
		frame.getContentPane().add(lblCurrentPassword);
		
		JLabel lblNewPassword = new JLabel("New Password");
		lblNewPassword.setBounds(337, 183, 126, 14);
		frame.getContentPane().add(lblNewPassword);
		
		txtNewPass = new JTextField();
		txtNewPass.setBounds(337, 200, 86, 20);
		frame.getContentPane().add(txtNewPass);
		txtNewPass.setColumns(10);
		
		JComboBox cbxHours = new JComboBox();
		cbxHours.setModel(new DefaultComboBoxModel(new String[] {"00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24"}));
		cbxHours.setBounds(320, 282, 58, 20);
		frame.getContentPane().add(cbxHours);
		
		JComboBox cbxMinutes = new JComboBox();
		cbxMinutes.setModel(new DefaultComboBoxModel(new String[] {"00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59"}));
		cbxMinutes.setBounds(405, 282, 58, 20);
		frame.getContentPane().add(cbxMinutes);
		
		JButton btnReminder = new JButton("Set Reminder");
		btnReminder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				String hours = cbxHours.getSelectedItem().toString();
				String minutes = cbxMinutes.getSelectedItem().toString();
				
				String time = hours + ":" + minutes;
				String content = txtReminder.getText();
				
				conn.setReminder(time, content);
			}
		});
		btnReminder.setBounds(320, 331, 143, 23);
		frame.getContentPane().add(btnReminder);
		
		JLabel lblHours = new JLabel("Hours");
		lblHours.setBounds(320, 306, 58, 14);
		frame.getContentPane().add(lblHours);
		
		JLabel lblMinutes = new JLabel("Minutes");
		lblMinutes.setBounds(405, 306, 75, 14);
		frame.getContentPane().add(lblMinutes);
		
		txtReminder = new JTextField();
		txtReminder.setText("Enter Reminder");
		txtReminder.setBounds(320, 251, 143, 20);
		frame.getContentPane().add(txtReminder);
		txtReminder.setColumns(10);
		
		
		

		
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				String user = txtUsername.getText();
				String pass = txtPassword.getText();
				Timer clock = new Timer(conn, user, txtarChatRoom);
				
				if(LoggedCheck == false)
				{
					conn.sendLogin(user, pass);
					
					//If it's successful, do nothing. If not, login is rejected.
					//Converted to int, because string if statement did not pass for some reason
					if (Integer.parseInt(conn.getResponse()) == 200)
					{
						LoggedCheck = true;
						lblUser.setText("Logged in as user: " + user);
						btnLogin.setText("Logout");
						
						clock.start();
					}
					
					else
					{
						JOptionPane.showMessageDialog(null, "Login Rejected: Try again");
					}
				}
				
				else
				{
					clock.stop();
					conn.logOut(user);
					txtIP.setEnabled(true);
					txtPort.setEnabled(true);
					btnConnect.setEnabled(true);
					btnLogin.setEnabled(false);
					btnLogin.setText("Login");
					btnConnect.setText("Reconnect");
					lblConError.setText("Disconnected");
					LoggedCheck = false;
					txtarUsers.setText(null);
				}
			}
		});
		
		btnConnect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				List<String> accList = new ArrayList<String>();
				
				String IP = txtIP.getText();
				int port = Integer.parseInt(txtPort.getText());
				
				int i = 0;
				
				conn.connectIt(IP, port);
				
				if (conn.getError1() == 0)
				{
					txtIP.setEnabled(false);
					txtPort.setEnabled(false);
					btnConnect.setEnabled(false);
					lblConError.setForeground(Color.GREEN);
					lblConError.setText("Connection Accepted");
					
					txtUsername.setEnabled(true);
					txtPassword.setEnabled(true);
					btnLogin.setEnabled(true);
					accList = conn.retrieveAccounts();
					System.out.println(accList);
					
					while (i < accList.size())
					{
						txtarUsers.append(accList.get(i) + "\r\n");
						cbxUsers.addItem(accList.get(i));
						i++;
					}
					
					
					conn.connectIt(IP, port);
				}
				
				else
				{
					lblConError.setForeground(Color.RED);
					lblConError.setText("Connection Failed");
				}
			}
		});
		
		
		
		
		
		
		
		
	}
}
