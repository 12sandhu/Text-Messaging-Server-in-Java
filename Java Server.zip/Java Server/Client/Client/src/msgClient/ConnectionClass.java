package msgClient;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

public class ConnectionClass 
{
	private int error1 = 0;
	private List<String> accList = new ArrayList<String>();
	private String serverResponse;
	private String sender = null;
	private String date = null;
	private String msg = null;
	private Socket conn = null;
	private PrintWriter print = null;
	private BufferedWriter bout = null;
	private BufferedReader bin = null;

	public ConnectionClass() 
	{


	}

	public void connectIt(String IP, int port)
	{
		try 
		{
			conn = new Socket(IP, port);
			error1 = 0;
		} 

		catch (UnknownHostException e) 
		{
			error1 = 1;
		} 

		catch (IOException e) 
		{
			error1 = 1;
		}
	}

	public int getError1()
	{
		return error1;
	}
	
	public void getMessage(String user)
	{
		
		
		try 
		{
			print = new PrintWriter(conn.getOutputStream(), true);
			bin = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String line = null;
			
			System.out.println(user);
			
			print.println("105");
			print.println(user);
			
			//we do not need the first two inputs
			line = bin.readLine().toString();
			
			//And if the second input says this, it will stop. Else, read the next three important ones
			if (line.contains("500"))
			{
				System.out.println("No mess");
				serverResponse = bin.readLine();
			}
			
			else
			{
				//if it found a message, we skip the next line as it is useless to us
				bin.readLine();
				System.out.println("Found mess" + line);
				sender = bin.readLine();
				date = bin.readLine();
				msg = bin.readLine();
				
				serverResponse = "200";
			}
			
		} 
		
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String getMsgSender()
	{
		return sender;
	}
	
	public String getMsgDate()
	{
		return date;
	}
	
	public String getMsgContent()
	{
		return msg;
	}
	
	public void sendMessage(String user, String recipient, String message)
	{
		try 
		{
			print = new PrintWriter(conn.getOutputStream(), true);
			bin = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			
			print.println("103");
			print.println(user);
			print.println(recipient);
			print.println(message);
			
			serverResponse = bin.readLine();
		} 
		
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void registerAcc(String user, String pass)
	{
		try 
		{
			print = new PrintWriter(conn.getOutputStream(), true);
			bin = new BufferedReader(new InputStreamReader(conn.getInputStream()));

			print.println("107");
			print.println(user);
			print.println(pass);

			serverResponse = bin.readLine();
		}

		catch (IOException e) 
		{
			System.out.println("Hello there");
		}
	}
	
	public void setReminder(String time, String content)
	{
		try 
		{
			print = new PrintWriter(conn.getOutputStream(), true);
			bin = new BufferedReader(new InputStreamReader(conn.getInputStream()));

			print.println("109");
			print.println(time);
			print.println(content);
		}

		catch (IOException e) 
		{
			System.out.println("Hello there");
		}
	}
	
	public void changeAccount(String oldpass, String newpass)
	{
		try 
		{
			print = new PrintWriter(conn.getOutputStream(), true);
			bin = new BufferedReader(new InputStreamReader(conn.getInputStream()));

			print.println("108");
			print.println(oldpass);
			print.println(newpass);

			serverResponse = bin.readLine();
		}

		catch (IOException e) 
		{
			System.out.println("Hello there");
		}
	}

	//When called, it will use the input to login to the server
	public void sendLogin(String user, String pass)
	{
		try 
		{
			print = new PrintWriter(conn.getOutputStream(), true);
			bin = new BufferedReader(new InputStreamReader(conn.getInputStream()));

			print.println("101");
			print.println(user);
			print.println(pass);

			serverResponse = bin.readLine();
		}

		catch (IOException e) 
		{
			System.out.println("Hello there");
		}
	}

	//Class to send command to log out
	public void logOut(String user)
	{
		try 
		{
			print = new PrintWriter(conn.getOutputStream(), true);
			bin = new BufferedReader(new InputStreamReader(conn.getInputStream()));

			print.println("102");
			print.println(user);

			serverResponse = bin.readLine();
		}

		catch (IOException e) 
		{
			System.out.println("Hello there");
		}
	}


	public List<String> retrieveAccounts()
	{
		int i = 0;
		String line = "";
		try 
		{
			print = new PrintWriter(conn.getOutputStream(), true);
			bin = new BufferedReader(new InputStreamReader(conn.getInputStream()));

			print.println("111");
			
			while ((line = bin.readLine()) != null)
			{
				accList.add(line);
				System.out.println(accList);
			}
			
			System.out.println(accList);
			
		} 

		catch (IOException e) 
		{
			e.printStackTrace();
		}
		
		return accList;
	}

	public String getResponse()
	{
		return serverResponse;
	}

}
