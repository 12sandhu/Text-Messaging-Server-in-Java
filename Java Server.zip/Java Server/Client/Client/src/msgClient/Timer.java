package msgClient;

import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JTextArea;

public class Timer extends Thread
{
	private ConnectionClass conn;
	private String user;
	private JTextArea txtarChatRoom;
	
	public Timer(ConnectionClass conn, String user, JTextArea txtarChatRoom)
	{
		this.txtarChatRoom = txtarChatRoom;
		this.conn = conn;
		this.user = user;
	}
	
	public void run()
	{
		while (true)
		{
			System.out.println(user);
			try 
			{
				conn.getMessage(user);
				
				String first = conn.getResponse();
				
				System.out.println(first);
				
				if (first.contains("No messages"))
				{
					
				}
				
				else
				{
					txtarChatRoom.append(conn.getMsgSender() + ": " + conn.getMsgContent() + "\r\n");
				}
				
				
				Thread.sleep(500);
			} 
			
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		}
	}
}
